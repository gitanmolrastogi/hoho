CKEDITOR.editorConfig = function (config) {
   config.autoParagraph = false;
   config.basicEntities = false;
   //config.removeFormatTags = 'p,li,br';
   config.fillEmptyBlocks = false;
}
;
